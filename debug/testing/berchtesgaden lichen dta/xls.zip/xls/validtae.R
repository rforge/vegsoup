spc <- read.csv2("/Users/roli/Dropbox/Rpackages/vegbase/debug/testing/berchtesgaden lichen dta/species.csv")
spc$abbr <- as.character(spc$abbr)
txa <- read.csv2("/Users/roli/Dropbox/Rpackages/vegbase/debug/testing/berchtesgaden lichen dta/taxonomy.csv")

txa$abbr <- as.character(txa$abbr)

u.spc <- unique(spc$abbr)
txa.out <- txa[match(u.spc, txa$abbr), ]
write.csv2(txa.out, "/Users/roli/Dropbox/Rpackages/vegbase/debug/testing/berchtesgaden lichen dta/taxonomy out.csv")